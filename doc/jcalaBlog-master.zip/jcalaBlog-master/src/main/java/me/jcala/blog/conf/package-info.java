/**
 * spring配置文件类所在的包
 *
 * 包下的类全都使用了@Configuration注解
 *
 * 包括数据库的配置和拦截器的配置等
 */
package me.jcala.blog.conf;