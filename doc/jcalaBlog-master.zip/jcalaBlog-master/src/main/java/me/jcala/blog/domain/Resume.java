package me.jcala.blog.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by Administrator on 2016/9/13.
 */
@Getter
@Setter
public class Resume {
    private String md;
    private String article;
}
