/**
 * 一些为了简化service操作的工具类
 */
package me.jcala.blog.utils;