/**
 * 所有service接口所在的包
 *
 * 实现类在me.jcala.blog.service包下
 */
package me.jcala.blog.service.inter;