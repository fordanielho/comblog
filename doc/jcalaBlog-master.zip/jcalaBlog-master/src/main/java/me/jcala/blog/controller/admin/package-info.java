/**
 * 后台管理页面的控制器
 *
 * 此包下的url一般都以/admin开头
 *
 * 并用了登录拦截器进行了拦截，只有登录之后才可以访问
 */
package me.jcala.blog.controller.admin;